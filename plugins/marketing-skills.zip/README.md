# Marketing Skills Plugin

32 marketing skills for technical marketers and founders, originally created by [Corey Haines](https://corey.co). Packaged as a Cowork plugin for easy installation.

## Skills

### Conversion Rate Optimization (CRO)
- **page-cro** — Optimize any marketing page for conversions
- **signup-flow-cro** — Improve signup and registration flows
- **onboarding-cro** — Post-signup activation and time-to-value
- **form-cro** — Optimize lead capture and contact forms
- **popup-cro** — Create and optimize popups, modals, and overlays
- **paywall-upgrade-cro** — In-app paywalls and upgrade screens
- **ab-test-setup** — Plan and implement A/B tests

### Content & Copy
- **copywriting** — Write marketing copy for any page
- **copy-editing** — Edit and improve existing copy
- **content-strategy** — Plan what content to create
- **social-content** — Create social media content across platforms
- **competitor-alternatives** — Competitor comparison and alternative pages

### SEO
- **seo-audit** — Audit and diagnose SEO issues
- **ai-seo** — Optimize for AI search engines and LLM citations
- **programmatic-seo** — Create SEO pages at scale
- **schema-markup** — Add and optimize structured data
- **site-architecture** — Plan site hierarchy and navigation

### Email & Outreach
- **email-sequence** — Drip campaigns, welcome sequences, lifecycle emails
- **cold-email** — B2B cold outreach that gets replies

### Paid Advertising
- **paid-ads** — Campaign strategy, targeting, and optimization
- **ad-creative** — Generate ad copy variations at scale

### Growth & Strategy
- **launch-strategy** — Product launches and feature announcements
- **marketing-ideas** — Marketing inspiration when you're stuck
- **marketing-psychology** — Apply behavioral science to marketing
- **free-tool-strategy** — Build free tools for lead generation
- **referral-program** — Referral and affiliate programs

### Revenue & Sales
- **pricing-strategy** — Pricing decisions and packaging
- **revops** — Revenue operations and lead lifecycle
- **sales-enablement** — Sales decks, one-pagers, and collateral
- **churn-prevention** — Reduce churn and build retention systems

### Analytics & Tracking
- **analytics-tracking** — Set up and audit marketing measurement

### Setup
- **product-marketing-context** — Create foundational context that all other skills reference

## Getting Started

After installing, start with the **product-marketing-context** skill to set up your product, audience, and positioning context. All other skills reference this context automatically.

## Usage

Skills trigger automatically based on what you ask. Examples:

- "Help me optimize my pricing page" → triggers **page-cro**
- "Write a cold email sequence for CTOs" → triggers **cold-email**
- "My signup conversion rate is terrible" → triggers **signup-flow-cro**
- "Create a LinkedIn post about our launch" → triggers **social-content**
- "Why am I not ranking on Google?" → triggers **seo-audit**

## Credits

Created by [Corey Haines](https://corey.co) ([GitHub](https://github.com/coreyhaines31/marketingskills)). Packaged for Cowork by Katana engineering.
